var require = meteorInstall({"imports":{"api":{"blog":{"blogs.js":["meteor/meteor","meteor/mongo","meteor/check",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                 //
// imports/api/blog/blogs.js                                                                       //
//                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                   //
module.export({                                                                                    // 1
    Blogs: function () {                                                                           // 1
        return Blogs;                                                                              // 1
    }                                                                                              // 1
});                                                                                                // 1
var Meteor = void 0;                                                                               // 1
module.import('meteor/meteor', {                                                                   // 1
    "Meteor": function (v) {                                                                       // 1
        Meteor = v;                                                                                // 1
    }                                                                                              // 1
}, 0);                                                                                             // 1
var Mongo = void 0;                                                                                // 1
module.import('meteor/mongo', {                                                                    // 1
    "Mongo": function (v) {                                                                        // 1
        Mongo = v;                                                                                 // 1
    }                                                                                              // 1
}, 1);                                                                                             // 1
var check = void 0;                                                                                // 1
module.import('meteor/check', {                                                                    // 1
    "check": function (v) {                                                                        // 1
        check = v;                                                                                 // 1
    }                                                                                              // 1
}, 2);                                                                                             // 1
var Match = void 0;                                                                                // 1
module.import('meteor/check', {                                                                    // 1
    "Match": function (v) {                                                                        // 1
        Match = v;                                                                                 // 1
    }                                                                                              // 1
}, 3);                                                                                             // 1
var Blogs = new Mongo.Collection('blogs');                                                         // 6
                                                                                                   //
function getValidBlogSelector(selector, userId) {                                                  // 7
    return {                                                                                       // 8
        $and: [{                                                                                   // 9
            $or: [{                                                                                // 11
                "private": {                                                                       // 12
                    $ne: true                                                                      // 13
                }                                                                                  // 12
            }, {                                                                                   // 11
                owner: userId                                                                      // 16
            }]                                                                                     // 15
        }, selector]                                                                               // 10
    };                                                                                             // 8
}                                                                                                  // 22
                                                                                                   //
if (Meteor.isServer) {                                                                             // 23
    // This code only runs on the server                                                           // 24
    // Only publish tasks that are public or belong to the current user                            // 25
    Meteor.publish('blogs', function () {                                                          // 26
        function blogsPublication(selector, opt) {                                                 // 26
            var res = Blogs.find(getValidBlogSelector(selector, this.userId), opt);                // 27
            return res;                                                                            // 28
        }                                                                                          // 29
                                                                                                   //
        return blogsPublication;                                                                   // 26
    }());                                                                                          // 26
}                                                                                                  // 30
                                                                                                   //
Meteor.methods({                                                                                   // 32
    'blogs.insert': function (blog, cb) {                                                          // 33
        var pattern;                                                                               // 34
        pattern = {                                                                                // 35
            title: String,                                                                         // 35
            content: String,                                                                       // 35
            excerpt: String,                                                                       // 35
            tags: Array,                                                                           // 35
            "private": Boolean                                                                     // 35
        };                                                                                         // 35
        check(blog, pattern); // Make sure the user is logged in before inserting a task           // 36
                                                                                                   //
        if (!Meteor.userId()) {                                                                    // 39
            throw new Meteor.Error('not-authorized');                                              // 40
        }                                                                                          // 41
                                                                                                   //
        var tagIds = [];                                                                           // 42
                                                                                                   //
        if (!!blog.tags) {                                                                         // 43
            for (var i = 0; i < blog.tags.length; i++) {                                           // 44
                tagIds.push({                                                                      // 45
                    _id: blog.tags[i]._id                                                          // 46
                });                                                                                // 45
            }                                                                                      // 48
        }                                                                                          // 49
                                                                                                   //
        return Blogs.insert({                                                                      // 50
            title: blog.title,                                                                     // 51
            content: blog.content,                                                                 // 52
            excerpt: blog.excerpt,                                                                 // 53
            tags: blog.tags,                                                                       // 54
            createdAt: new Date(),                                                                 // 55
            owner: Meteor.userId(),                                                                // 56
            username: Meteor.user().username,                                                      // 57
            "private": blog.private                                                                // 58
        }, cb);                                                                                    // 50
    },                                                                                             // 60
    'blogs.update': function (blog, cb) {                                                          // 61
        var pattern;                                                                               // 62
        pattern = {                                                                                // 63
            title: String,                                                                         // 64
            content: String,                                                                       // 65
            excerpt: String,                                                                       // 66
            _id: String,                                                                           // 67
            createdAt: Date,                                                                       // 68
            owner: String,                                                                         // 69
            username: String,                                                                      // 70
            tags: Array,                                                                           // 71
            "private": Boolean                                                                     // 72
        };                                                                                         // 63
        check(blog, pattern);                                                                      // 74
                                                                                                   //
        if (Meteor.userId() !== blog.owner) {                                                      // 76
            // If the task is private, make sure only the owner can delete it                      // 77
            throw new Meteor.Error('not-authorized');                                              // 78
        }                                                                                          // 79
                                                                                                   //
        return Blogs.update({                                                                      // 81
            _id: blog._id,                                                                         // 81
            owner: blog.owner                                                                      // 81
        }, {                                                                                       // 81
            $set: {                                                                                // 82
                title: blog.title,                                                                 // 83
                content: blog.content,                                                             // 84
                excerpt: blog.excerpt,                                                             // 85
                tags: blog.tags,                                                                   // 86
                "private": blog.private                                                            // 87
            }                                                                                      // 82
        }, cb);                                                                                    // 81
    },                                                                                             // 90
    'blogs.get': function (blogId) {                                                               // 91
        check(blogId, String);                                                                     // 92
        var blog = Blogs.findOne(blogId);                                                          // 94
                                                                                                   //
        if (!!blog && blog.private && blog.owner !== Meteor.userId()) {                            // 96
            // If the task is private, make sure only the owner can delete it                      // 97
            throw new Meteor.Error('not-authorized');                                              // 98
        }                                                                                          // 99
                                                                                                   //
        return blog;                                                                               // 100
    },                                                                                             // 101
    'blogs.recent': function (blogId, tagId) {                                                     // 102
        check(blogId, String);                                                                     // 103
        var blog = Blogs.findOne(blogId);                                                          // 104
                                                                                                   //
        if (!blog) {                                                                               // 105
            return null;                                                                           // 106
        }                                                                                          // 107
                                                                                                   //
        if (!!blog && blog.private && blog.owner !== Meteor.userId()) {                            // 109
            // If the task is private, make sure only the owner can delete it                      // 110
            throw new Meteor.Error('not-authorized');                                              // 111
        }                                                                                          // 112
                                                                                                   //
        var select = {};                                                                           // 113
                                                                                                   //
        if (tagId) {                                                                               // 114
            select['tags'] = {                                                                     // 115
                $elemMatch: {                                                                      // 115
                    _id: tagId                                                                     // 115
                }                                                                                  // 115
            };                                                                                     // 115
        }                                                                                          // 116
                                                                                                   //
        select['createdAt'] = {                                                                    // 117
            '$lt': blog.createdAt                                                                  // 117
        };                                                                                         // 117
        var prevBlog = Blogs.find(getValidBlogSelector(select, Meteor.userId()), {                 // 118
            sort: {                                                                                // 119
                createdAt: -1                                                                      // 120
            },                                                                                     // 119
            limit: 1                                                                               // 122
        }).fetch();                                                                                // 118
        select['createdAt'] = {                                                                    // 124
            '$gt': blog.createdAt                                                                  // 124
        };                                                                                         // 124
        var nextBlog = Blogs.find(getValidBlogSelector(select, Meteor.userId()), {                 // 125
            sort: {                                                                                // 126
                createdAt: 1                                                                       // 127
            },                                                                                     // 126
            limit: 1                                                                               // 129
        }).fetch();                                                                                // 125
        return {                                                                                   // 131
            prev: prevBlog[0],                                                                     // 132
            next: nextBlog[0]                                                                      // 133
        };                                                                                         // 131
    },                                                                                             // 135
    'blogs.remove': function (blogId, cb) {                                                        // 136
        check(blogId, String);                                                                     // 137
        var blog = Blogs.findOne(blogId);                                                          // 139
                                                                                                   //
        if (blog.private && blog.owner !== Meteor.userId()) {                                      // 140
            // If the task is private, make sure only the owner can delete it                      // 141
            throw new Meteor.Error('not-authorized');                                              // 142
        }                                                                                          // 143
                                                                                                   //
        Blogs.remove(blogId, cb);                                                                  // 145
    },                                                                                             // 146
    'blogs.setTags': function (blogId, tags) {                                                     // 147
        check(blogId, String);                                                                     // 148
        check(tags, Array);                                                                        // 149
        var task = Blogs.findOne(blogId);                                                          // 152
                                                                                                   //
        if (task.private && task.owner !== Meteor.userId()) {                                      // 153
            // If the task is private, make sure only the owner can check it off                   // 154
            throw new Meteor.Error('not-authorized');                                              // 155
        }                                                                                          // 156
                                                                                                   //
        Blogs.update(blogId, {                                                                     // 158
            $set: {                                                                                // 159
                tags: tags                                                                         // 160
            }                                                                                      // 159
        });                                                                                        // 158
    },                                                                                             // 163
    'blogs.setPrivate': function (blogId, setToPrivate) {                                          // 164
        check(blogId, String);                                                                     // 165
        check(setToPrivate, Boolean);                                                              // 166
        var task = Blogs.findOne(blogId); // Make sure only the task owner can make a task private
                                                                                                   //
        if (task.owner !== Meteor.userId()) {                                                      // 171
            throw new Meteor.Error('not-authorized');                                              // 172
        }                                                                                          // 173
                                                                                                   //
        Blogs.update(blogId, {                                                                     // 175
            $set: {                                                                                // 176
                "private": setToPrivate                                                            // 177
            }                                                                                      // 176
        });                                                                                        // 175
    }                                                                                              // 180
});                                                                                                // 32
/////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"common":{"server-env.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                 //
// imports/api/common/server-env.js                                                                //
//                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                   //
/**                                                                                                // 1
 * Created by 89 on 2017/3/31.                                                                     //
 */Meteor.methods({                                                                                //
    'getServerEnv': function () {                                                                  // 5
        return {                                                                                   // 6
            server_url: process.env.MOBILE_ROOT_URL || process.env.ROOT_URL                        // 7
        };                                                                                         // 6
    }                                                                                              // 9
});                                                                                                // 4
/////////////////////////////////////////////////////////////////////////////////////////////////////

}},"tag":{"tags.js":["meteor/meteor","meteor/mongo","meteor/check",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                 //
// imports/api/tag/tags.js                                                                         //
//                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                   //
module.export({                                                                                    // 1
    Tags: function () {                                                                            // 1
        return Tags;                                                                               // 1
    }                                                                                              // 1
});                                                                                                // 1
var Meteor = void 0;                                                                               // 1
module.import('meteor/meteor', {                                                                   // 1
    "Meteor": function (v) {                                                                       // 1
        Meteor = v;                                                                                // 1
    }                                                                                              // 1
}, 0);                                                                                             // 1
var Mongo = void 0;                                                                                // 1
module.import('meteor/mongo', {                                                                    // 1
    "Mongo": function (v) {                                                                        // 1
        Mongo = v;                                                                                 // 1
    }                                                                                              // 1
}, 1);                                                                                             // 1
var check = void 0;                                                                                // 1
module.import('meteor/check', {                                                                    // 1
    "check": function (v) {                                                                        // 1
        check = v;                                                                                 // 1
    }                                                                                              // 1
}, 2);                                                                                             // 1
var Match = void 0;                                                                                // 1
module.import('meteor/check', {                                                                    // 1
    "Match": function (v) {                                                                        // 1
        Match = v;                                                                                 // 1
    }                                                                                              // 1
}, 3);                                                                                             // 1
var Tags = new Mongo.Collection('tags');                                                           // 9
                                                                                                   //
if (Meteor.isServer) {                                                                             // 11
    // This code only runs on the server                                                           // 12
    // Only publish tasks that are public or belong to the current user                            // 13
    Meteor.publish('tags', function () {                                                           // 14
        function tagsPublication() {                                                               // 14
            var res = Tags.find({                                                                  // 15
                $or: [{                                                                            // 16
                    "private": {                                                                   // 17
                        $ne: true                                                                  // 18
                    }                                                                              // 17
                }, {                                                                               // 16
                    owner: this.userId                                                             // 21
                }]                                                                                 // 20
            });                                                                                    // 15
            return res;                                                                            // 24
        }                                                                                          // 25
                                                                                                   //
        return tagsPublication;                                                                    // 14
    }());                                                                                          // 14
}                                                                                                  // 26
                                                                                                   //
Meteor.methods({                                                                                   // 28
    'tags.insert': function (tag, cb) {                                                            // 29
        var pattern;                                                                               // 30
        pattern = {                                                                                // 31
            name: String                                                                           // 31
        };                                                                                         // 31
        check(tag, pattern); // Make sure the user is logged in before inserting a task            // 32
                                                                                                   //
        if (!Meteor.userId()) {                                                                    // 35
            throw new Meteor.Error('not-authorized');                                              // 36
        }                                                                                          // 37
                                                                                                   //
        var theTag = Tags.findOne({                                                                // 38
            name: tag.name,                                                                        // 38
            owner: Meteor.userId()                                                                 // 38
        });                                                                                        // 38
                                                                                                   //
        if (!!theTag) {                                                                            // 39
            throw new Meteor.Error('name repeat');                                                 // 40
        }                                                                                          // 41
                                                                                                   //
        return Tags.insert({                                                                       // 42
            createdAt: new Date(),                                                                 // 43
            name: tag.name,                                                                        // 44
            owner: Meteor.userId()                                                                 // 45
        }, cb);                                                                                    // 42
    },                                                                                             // 47
    'tags.update': function (tag, cb) {                                                            // 48
        var pattern;                                                                               // 49
        pattern = {                                                                                // 50
            name: String,                                                                          // 51
            _id: String                                                                            // 52
        };                                                                                         // 50
        check(tag, pattern);                                                                       // 54
        return Tags.update({                                                                       // 56
            _id: tag._id,                                                                          // 56
            owner: Meteor.userId()                                                                 // 56
        }, {                                                                                       // 56
            $set: {                                                                                // 57
                name: tag.name                                                                     // 58
            }                                                                                      // 57
        }, cb);                                                                                    // 56
    },                                                                                             // 61
    'tags.get': function (tagId) {                                                                 // 62
        check(tagId, String);                                                                      // 63
        var tag = Tags.findOne(tagId);                                                             // 65
        return tag;                                                                                // 66
    },                                                                                             // 67
    'tags.getByName': function (name, cb) {                                                        // 68
        check(name, String);                                                                       // 69
        var tag = Tags.findOne({                                                                   // 70
            name: name,                                                                            // 70
            owner: Meteor.userId()                                                                 // 70
        });                                                                                        // 70
        return tag;                                                                                // 72
    },                                                                                             // 73
    'tags.remove': function (tagId, cb) {                                                          // 74
        var tagIds = [];                                                                           // 75
                                                                                                   //
        if (!(tagId instanceof Array)) {                                                           // 76
            tagIds.push(tagId);                                                                    // 77
        } else {                                                                                   // 78
            tagIds = tagId;                                                                        // 79
        }                                                                                          // 80
                                                                                                   //
        check(tagIds, Array);                                                                      // 81
        var tag = Tags.find({                                                                      // 82
            '_id': {                                                                               // 82
                '$in': tagIds                                                                      // 82
            }                                                                                      // 82
        });                                                                                        // 82
        tag.forEach(function (ele) {                                                               // 83
            if (ele.owner !== Meteor.userId()) {                                                   // 84
                // If the task is private, make sure only the owner can delete it                  // 85
                throw new Meteor.Error('not-authorized: ' + ele.name);                             // 86
            }                                                                                      // 87
        });                                                                                        // 88
        Tags.remove({                                                                              // 89
            '_id': {                                                                               // 89
                '$in': tagIds                                                                      // 89
            }                                                                                      // 89
        }, cb);                                                                                    // 89
    }                                                                                              // 90
});                                                                                                // 28
/////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"upload":{"upload.js":["meteor/meteor","meteor/mongo","meteor/check","meteor/ostrio:files",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                 //
// imports/api/upload/upload.js                                                                    //
//                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                   //
module.export({                                                                                    // 1
    Images: function () {                                                                          // 1
        return Images;                                                                             // 1
    }                                                                                              // 1
});                                                                                                // 1
var Meteor = void 0;                                                                               // 1
module.import('meteor/meteor', {                                                                   // 1
    "Meteor": function (v) {                                                                       // 1
        Meteor = v;                                                                                // 1
    }                                                                                              // 1
}, 0);                                                                                             // 1
var Mongo = void 0;                                                                                // 1
module.import('meteor/mongo', {                                                                    // 1
    "Mongo": function (v) {                                                                        // 1
        Mongo = v;                                                                                 // 1
    }                                                                                              // 1
}, 1);                                                                                             // 1
var check = void 0;                                                                                // 1
module.import('meteor/check', {                                                                    // 1
    "check": function (v) {                                                                        // 1
        check = v;                                                                                 // 1
    }                                                                                              // 1
}, 2);                                                                                             // 1
var Match = void 0;                                                                                // 1
module.import('meteor/check', {                                                                    // 1
    "Match": function (v) {                                                                        // 1
        Match = v;                                                                                 // 1
    }                                                                                              // 1
}, 3);                                                                                             // 1
var FilesCollection = void 0;                                                                      // 1
module.import('meteor/ostrio:files', {                                                             // 1
    "FilesCollection": function (v) {                                                              // 1
        FilesCollection = v;                                                                       // 1
    }                                                                                              // 1
}, 4);                                                                                             // 1
var Images = new FilesCollection({                                                                 // 11
    debug: false,                                                                                  // 12
    collectionName: 'Images',                                                                      // 13
    allowClientCode: true,                                                                         // 14
    // Disallow remove files from Client                                                           // 14
    storagePath: Meteor.absolutePath + '/.upload/imgs',                                            // 15
    onBeforeUpload: function (file) {                                                              // 16
        // Allow upload files under 10MB, and only in png/jpg/jpeg formats                         // 17
        file.link = 'imgs/' + file._id + '.' + file.extension;                                     // 18
        file.createdAt = new Date(); // console.dir(file)                                          // 19
                                                                                                   //
        if (file.size <= 1024 * 1024 * 10 && /png|jpg|jpeg|gif|bmp/i.test(file.extension)) {       // 21
            return true;                                                                           // 22
        } else {                                                                                   // 23
            return 'Please upload image, with size equal or less than 10MB';                       // 24
        }                                                                                          // 25
    }                                                                                              // 26
});                                                                                                // 11
                                                                                                   //
if (Meteor.isServer) {                                                                             // 29
    Images.denyClient();                                                                           // 30
    Meteor.publish('files.images.all', function () {                                               // 31
        return Images.find().cursor;                                                               // 32
    });                                                                                            // 33
} else {                                                                                           // 35
    Meteor.subscribe('files.images.all');                                                          // 37
}                                                                                                  // 38
/////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"tasks.js":["meteor/meteor","meteor/mongo","meteor/check",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                 //
// imports/api/tasks.js                                                                            //
//                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                   //
module.export({                                                                                    // 1
    Tasks: function () {                                                                           // 1
        return Tasks;                                                                              // 1
    }                                                                                              // 1
});                                                                                                // 1
var Meteor = void 0;                                                                               // 1
module.import('meteor/meteor', {                                                                   // 1
    "Meteor": function (v) {                                                                       // 1
        Meteor = v;                                                                                // 1
    }                                                                                              // 1
}, 0);                                                                                             // 1
var Mongo = void 0;                                                                                // 1
module.import('meteor/mongo', {                                                                    // 1
    "Mongo": function (v) {                                                                        // 1
        Mongo = v;                                                                                 // 1
    }                                                                                              // 1
}, 1);                                                                                             // 1
var check = void 0;                                                                                // 1
module.import('meteor/check', {                                                                    // 1
    "check": function (v) {                                                                        // 1
        check = v;                                                                                 // 1
    }                                                                                              // 1
}, 2);                                                                                             // 1
var Tasks = new Mongo.Collection('tasks');                                                         // 5
                                                                                                   //
if (Meteor.isServer) {                                                                             // 7
    // This code only runs on the server                                                           // 8
    // Only publish tasks that are public or belong to the current user                            // 9
    Meteor.publish('tasks', function () {                                                          // 10
        function tasksPublication() {                                                              // 10
            return Tasks.find({                                                                    // 11
                $or: [{                                                                            // 12
                    "private": {                                                                   // 13
                        $ne: true                                                                  // 14
                    }                                                                              // 13
                }, {                                                                               // 12
                    owner: this.userId                                                             // 17
                }]                                                                                 // 16
            });                                                                                    // 11
        }                                                                                          // 20
                                                                                                   //
        return tasksPublication;                                                                   // 10
    }());                                                                                          // 10
}                                                                                                  // 21
                                                                                                   //
Meteor.methods({                                                                                   // 23
    'tasks.insert': function (text) {                                                              // 24
        check(text, String); // Make sure the user is logged in before inserting a task            // 25
                                                                                                   //
        if (!Meteor.userId()) {                                                                    // 28
            throw new Meteor.Error('not-authorized');                                              // 29
        }                                                                                          // 30
                                                                                                   //
        Tasks.insert({                                                                             // 32
            text: text,                                                                            // 33
            createdAt: new Date(),                                                                 // 34
            owner: Meteor.userId(),                                                                // 35
            username: Meteor.user().username                                                       // 36
        });                                                                                        // 32
    },                                                                                             // 38
    'tasks.remove': function (taskId) {                                                            // 39
        check(taskId, String);                                                                     // 40
        var task = Tasks.findOne(taskId);                                                          // 42
                                                                                                   //
        if (task.private && task.owner !== Meteor.userId()) {                                      // 43
            // If the task is private, make sure only the owner can delete it                      // 44
            throw new Meteor.Error('not-authorized');                                              // 45
        }                                                                                          // 46
                                                                                                   //
        Tasks.remove(taskId);                                                                      // 48
    },                                                                                             // 49
    'tasks.setChecked': function (taskId, setChecked) {                                            // 50
        check(taskId, String);                                                                     // 51
        check(setChecked, Boolean);                                                                // 52
        var task = Tasks.findOne(taskId);                                                          // 55
                                                                                                   //
        if (task.private && task.owner !== Meteor.userId()) {                                      // 56
            // If the task is private, make sure only the owner can check it off                   // 57
            throw new Meteor.Error('not-authorized');                                              // 58
        }                                                                                          // 59
                                                                                                   //
        Tasks.update(taskId, {                                                                     // 61
            $set: {                                                                                // 62
                checked: setChecked                                                                // 63
            }                                                                                      // 62
        });                                                                                        // 61
    },                                                                                             // 66
    'tasks.setPrivate': function (taskId, setToPrivate) {                                          // 67
        check(taskId, String);                                                                     // 68
        check(setToPrivate, Boolean);                                                              // 69
        var task = Tasks.findOne(taskId); // Make sure only the task owner can make a task private
                                                                                                   //
        if (task.owner !== Meteor.userId()) {                                                      // 74
            throw new Meteor.Error('not-authorized');                                              // 75
        }                                                                                          // 76
                                                                                                   //
        Tasks.update(taskId, {                                                                     // 78
            $set: {                                                                                // 79
                "private": setToPrivate                                                            // 80
            }                                                                                      // 79
        });                                                                                        // 78
    }                                                                                              // 83
});                                                                                                // 23
/////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},"server":{"common":{"index.js":["../../imports/api/common/server-env",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                 //
// server/common/index.js                                                                          //
//                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                   //
module.import('../../imports/api/common/server-env');                                              // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"tag":{"index.js":["../../imports/api/tag/tags.js",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                 //
// server/tag/index.js                                                                             //
//                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                   //
module.import('../../imports/api/tag/tags.js');                                                    // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"upload":{"index.js":["../../imports/api/upload/upload","fs",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                 //
// server/upload/index.js                                                                          //
//                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                   //
module.import('../../imports/api/upload/upload');                                                  // 1
                                                                                                   //
var fs = require('fs');                                                                            // 6
                                                                                                   //
WebApp.connectHandlers.use(function (req, res, next) {                                             // 7
    // console.dir(req.url)                                                                        // 8
    var re = /^\/imgs\/(.*)$/.exec(req.url);                                                       // 9
                                                                                                   //
    if (re !== null) {                                                                             // 10
        // Only handle URLs that start with /url_path/*                                            // 10
        var filePath;                                                                              // 11
                                                                                                   //
        if (Meteor.isProduction && /\/bundle$/.exec(process.env.PWD) != null) {                    // 12
            filePath = process.env.PWD + '/programs/server/.upload/imgs/' + re[1];                 // 13
        } else {                                                                                   // 14
            filePath = process.env.PWD + '/.upload/imgs/' + re[1];                                 // 15
        }                                                                                          // 16
                                                                                                   //
        var data = fs.readFileSync(filePath, data);                                                // 17
        res.writeHead(200, {                                                                       // 18
            'Content-Type': 'image'                                                                // 19
        });                                                                                        // 18
        res.write(data);                                                                           // 21
        res.end();                                                                                 // 22
    } else {                                                                                       // 23
        // Other urls will have default behaviors                                                  // 23
        next();                                                                                    // 24
    }                                                                                              // 25
});                                                                                                // 26
/////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"blog":{"main.js":["../../imports/api/blog/blogs.js",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                 //
// server/blog/main.js                                                                             //
//                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                   //
module.import('../../imports/api/blog/blogs.js');                                                  // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"todo":{"main.js":["../../imports/api/tasks.js",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                 //
// server/todo/main.js                                                                             //
//                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                   //
module.import('../../imports/api/tasks.js');                                                       // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"main.js":["meteor/meteor",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                 //
// server/main.js                                                                                  //
//                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                   //
var Meteor = void 0;                                                                               // 1
module.import('meteor/meteor', {                                                                   // 1
  "Meteor": function (v) {                                                                         // 1
    Meteor = v;                                                                                    // 1
  }                                                                                                // 1
}, 0);                                                                                             // 1
Meteor.startup(function () {// code to run on server at startup                                    // 3
});                                                                                                // 5
/////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},{"extensions":[".js",".json",".html"]});
require("./server/common/index.js");
require("./server/tag/index.js");
require("./server/upload/index.js");
require("./server/blog/main.js");
require("./server/todo/main.js");
require("./server/main.js");
//# sourceMappingURL=app.js.map
